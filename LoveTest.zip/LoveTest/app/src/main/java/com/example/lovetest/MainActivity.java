package com.example.lovetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        EditText bf = findViewById(R.id.editTextTextbf);
        String word1 = bf.getText().toString();

        EditText gf = findViewById(R.id.editTextTextgf);
        String word2 = gf.getText().toString();

        TextView out = findViewById(R.id.textView3);
        int unicode = 0x1F60D;
        int uni2 = 0x1F612;
        int uni3 = 0x1F498;
        String emoji = getEmoji(unicode);
        String emoji2 = getEmoji(uni2);
        String emoji3 = getEmoji(uni3);

        double count1 = 0;
        double count2 = 0;
        word1 = word1.toUpperCase();
        word2 = word2.toUpperCase();

        for (int i = 0; i < word1.length(); i++) {
            count2++;
            for (int j = 0; j < word2.length(); j++) {
                if (word1.charAt(i) == word2.charAt(j)) {
                    count1++;
                    break;
                }
            }
        }
        double percent = (count1 / count2) * 100;
        //String per = String.va
        if(word1.equals("LUKHONA")){
            out.setText("Congratulations you guys are highly compatible" + emoji + "," + word1 + " Marry " + word2 +emoji3+ " soon!!!");
            Toast.makeText(this, "Love is in the air"+emoji, Toast.LENGTH_SHORT).show();
        }
        else{
            if (percent < 50) {
                out.setText("Unfonately you guys are not compatible" + emoji2);
                Toast.makeText(this, "Sad"+emoji2, Toast.LENGTH_SHORT).show();
            } else {
                out.setText("Congratulations you guys are highly compatible" + emoji + "," + word1 + " Marry " + word2 +emoji3+ " soon!!!");
                Toast.makeText(this, "Love is in the air"+emoji, Toast.LENGTH_SHORT).show();
            }
        }

    }

    public String getEmoji(int uni) {
        return new String(Character.toChars(uni));
    }

}